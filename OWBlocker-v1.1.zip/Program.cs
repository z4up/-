﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Diagnostics;
using System.Drawing;
using System.IO;
using System.Net;
using System.Web.Script.Serialization;
using System.Windows.Forms;

class MainForm : Form
{
    string url = "https://github.com/Qiiks/ow2-server-list/raw/refs/heads/main/ow2-servers.json";
    Dictionary<string, List<string>> servers = new Dictionary<string, List<string>>();
    List<CheckBox> boxes = new List<CheckBox>();
    FlowLayoutPanel panel = new FlowLayoutPanel();
    Label status = new Label();
    string gamePath = "";
    string folder = Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.ApplicationData), "OWBlocker");
    CheckBox tempBox = new CheckBox();
    Label hintLabel;
    Dictionary<Button, string[]> texts = new Dictionary<Button, string[]>();
    bool arabic = false;
    string preset = "";
    NotifyIcon tray = new NotifyIcon();

    // change these when you publish a new release
    string repo = "YOUR_NAME/YOUR_REPO";
    string version = "1.1";

    // aws datacenters close to each region, ping is only an estimate
    string[] pingKeys = { "NA-East", "NA-Central", "NA-West", "EU", "Brazil", "Singapore", "Japan", "Korea", "Taiwan", "Australia", "MiddleEast" };
    string[] pingZones = { "us-east-1", "us-east-2", "us-west-1", "eu-central-1", "sa-east-1", "ap-southeast-1", "ap-northeast-1", "ap-northeast-2", "ap-east-2", "ap-southeast-2", "me-central-1" };

    int GetPing(string zone)
    {
        try
        {
            IPAddress ip = Array.Find(Dns.GetHostAddresses("dynamodb." + zone + ".amazonaws.com"),
                a => a.AddressFamily == System.Net.Sockets.AddressFamily.InterNetwork);
            using (var client = new System.Net.Sockets.TcpClient())
            {
                var watch = Stopwatch.StartNew();
                var result = client.BeginConnect(ip, 443, null, null);
                if (!result.AsyncWaitHandle.WaitOne(2000)) return -1;
                client.EndConnect(result);
                return (int)watch.ElapsedMilliseconds;
            }
        }
        catch { return -1; }
    }

    async void CheckPing(object sender, EventArgs e)
    {
        foreach (CheckBox c in boxes.ToArray())
        {
            string name = ((string)c.Tag).Replace("OW2-", "");
            int i = Array.IndexOf(pingKeys, name);
            if (i == -1) continue;
            c.Text = name + "\n...";
            int ms = await System.Threading.Tasks.Task.Run(() => GetPing(pingZones[i]));
            if (IsDisposed) return;
            c.Text = name + "\n" + (ms < 0 ? "?" : "~" + ms + " ms");
        }
    }

    async void CheckUpdate()
    {
        if (repo.StartsWith("YOUR_")) return;
        try
        {
            string json = await System.Threading.Tasks.Task.Run(() =>
            {
                ServicePointManager.SecurityProtocol = (SecurityProtocolType)3072;
                var web = new WebClient();
                web.Headers.Add("User-Agent", "OWBlocker");
                return web.DownloadString("https://api.github.com/repos/" + repo + "/releases/latest");
            });
            var data = new JavaScriptSerializer().Deserialize<Dictionary<string, object>>(json);
            string latest = data["tag_name"].ToString().TrimStart('v');
            if (new Version(latest) > new Version(version) &&
                MessageBox.Show(T("New version available. Open download page?", "فيه نسخة جديدة، تبي تفتح صفحة التحميل؟"),
                    "OW Server Blocker", MessageBoxButtons.YesNo) == DialogResult.Yes)
                Process.Start("https://github.com/" + repo + "/releases/latest");
        }
        catch { } // no internet or no releases yet, not a big deal
    }

    void ShowWindow()
    {
        Show();
        WindowState = FormWindowState.Normal;
        Activate();
    }

    void SetupTray()
    {
        tray.Icon = SystemIcons.Shield;
        tray.Text = "OW Server Blocker";
        tray.Visible = true;
        tray.DoubleClick += (o, e) => ShowWindow();
        var menu = new ContextMenuStrip();
        menu.Items.Add("Show / إظهار", null, (o, e) => ShowWindow());
        menu.Items.Add("Apply / تطبيق", null, (o, e) => { ShowWindow(); ApplyClick(o, e); });
        menu.Items.Add("Unblock all / فك الكل", null, (o, e) => UnblockClick(o, e));
        menu.Items.Add("Exit / خروج", null, (o, e) => Close());
        tray.ContextMenuStrip = menu;
        // minimize goes next to the clock, X still closes the app
        Resize += (o, e) => { if (WindowState == FormWindowState.Minimized) Hide(); };
        FormClosed += (o, e) => tray.Dispose();
    }

    [System.Runtime.InteropServices.DllImport("user32.dll")]
    static extern bool RegisterHotKey(IntPtr hWnd, int id, int mods, int key);

    string T(string en, string ar) { return arabic ? ar : en; }

    // ctrl+alt+U = unblock everything, works even while in game
    protected override void OnHandleCreated(EventArgs e)
    {
        base.OnHandleCreated(e);
        RegisterHotKey(Handle, 1, 0x1 | 0x2, (int)Keys.U);
    }

    protected override void WndProc(ref Message m)
    {
        if (m.Msg == 0x0312)
        {
            UnblockClick(null, null);
            System.Media.SystemSounds.Asterisk.Play();
        }
        base.WndProc(ref m);
    }

    // settings file: game path, temp mode, language, saved preset
    void SaveSettings()
    {
        try
        {
            Directory.CreateDirectory(folder);
            File.WriteAllLines(Path.Combine(folder, "settings.txt"),
                new string[] { gamePath, tempBox.Checked.ToString(), arabic.ToString(), preset });
        }
        catch { status.Text = T("Couldn't save settings", "ما قدرت أحفظ الإعدادات"); }
    }

    void LoadSettings()
    {
        string f = Path.Combine(folder, "settings.txt");
        if (!File.Exists(f)) return;
        string[] lines = File.ReadAllLines(f);
        if (lines.Length < 4) return;
        gamePath = lines[0];
        tempBox.Checked = lines[1] == "True";
        arabic = lines[2] == "True";
        preset = lines[3];
    }

    void SetLanguage()
    {
        foreach (var item in texts) item.Key.Text = T(item.Value[0], item.Value[1]);
        hintLabel.Text = T("Red = blocked. Press Apply. Panic key: Ctrl+Alt+U",
            "الأحمر = مبلوك، ثم اضغط تطبيق. فك سريع: Ctrl+Alt+U");
        tempBox.Text = T("Block only while this app is open", "البلوك فقط والبرنامج مفتوح");
        status.Text = "";
    }

    Color bg = Color.FromArgb(27, 32, 48);
    Color card = Color.FromArgb(42, 49, 72);
    Color orange = Color.FromArgb(249, 158, 26);
    Color red = Color.FromArgb(200, 60, 70);

    [STAThread]
    static void Main()
    {
        Application.EnableVisualStyles();
        Application.Run(new MainForm());
    }

    MainForm()
    {
        Text = "OW Server Blocker";
        ClientSize = new Size(520, 650);
        BackColor = bg;
        ForeColor = Color.White;
        Font = new Font("Segoe UI", 10);
        FormBorderStyle = FormBorderStyle.FixedSingle;
        MaximizeBox = false;
        StartPosition = FormStartPosition.CenterScreen;

        Label title = new Label();
        title.Text = "OW Server Blocker";
        title.Font = new Font("Segoe UI", 20, FontStyle.Bold);
        title.ForeColor = orange;
        title.SetBounds(20, 12, 480, 40);
        Controls.Add(title);

        Label hint = new Label();
        hintLabel = hint;
        hint.SetBounds(23, 56, 480, 22);
        Controls.Add(hint);

        panel.SetBounds(16, 86, 495, 330);
        Controls.Add(panel);

        MakeButton("Apply", "تطبيق", 20, 430, orange, ApplyClick);
        MakeButton("Block ME only", "بلوك ME فقط", 185, 430, card, MeClick);
        MakeButton("Unblock all", "فك الكل", 350, 430, card, UnblockClick);
        MakeButton("Save preset", "حفظ اختياري", 20, 480, card, SaveClick);
        MakeButton("Load preset", "استرجاع اختياري", 185, 480, card, LoadClick);
        MakeButton("عربي", "English", 350, 480, card, (o, e) => { arabic = !arabic; SetLanguage(); SaveSettings(); });

        LoadSettings();
        tempBox.SetBounds(23, 538, 315, 26);
        tempBox.CheckedChanged += (o, e) => SaveSettings();
        Controls.Add(tempBox);
        SetLanguage();
        FormClosing += (o, e) => { if (tempBox.Checked) RemoveAll(); };

        status.SetBounds(20, 590, 480, 50);
        Controls.Add(status);

        MakeButton("Check ping", "فحص البنق", 350, 530, card, CheckPing);
        SetupTray();

        Shown += (o, e) => { LoadServers(o, e); CheckUpdate(); };
    }

    void MakeButton(string en, string ar, int x, int y, Color color, EventHandler click)
    {
        Button b = new Button();
        texts[b] = new string[] { en, ar };
        b.SetBounds(x, y, 150, 42);
        b.BackColor = color;
        b.ForeColor = color == orange ? Color.Black : Color.White;
        b.FlatStyle = FlatStyle.Flat;
        b.FlatAppearance.BorderSize = 0;
        b.Click += click;
        Controls.Add(b);
    }

    void LoadServers(object sender, EventArgs e)
    {
        try
        {
            status.Text = "Loading servers...";
            status.Refresh();
            ServicePointManager.SecurityProtocol = (SecurityProtocolType)3072;
            string cache = Path.Combine(folder, "servers.json");
            string json;
            bool offline = false;
            try
            {
                json = new WebClient().DownloadString(url);
                // make sure it's valid before saving it
                var check = new JavaScriptSerializer().Deserialize<Dictionary<string, object>>(json);
                if (!check.ContainsKey("regions")) throw new Exception("Bad server list");
                Directory.CreateDirectory(folder);
                File.WriteAllText(cache, json);
            }
            catch
            {
                if (!File.Exists(cache)) throw;
                json = File.ReadAllText(cache);
                offline = true;
            }
            var data = new JavaScriptSerializer().Deserialize<Dictionary<string, object>>(json);
            var regions = (Dictionary<string, object>)data["regions"];

            foreach (var item in regions)
            {
                var info = (Dictionary<string, object>)item.Value;
                var list = new List<string>();
                foreach (object ip in (IEnumerable)info["cidrs"])
                {
                    // only accept stuff that looks like an ip range
                    IPAddress temp;
                    string s = ip.ToString();
                    if (IPAddress.TryParse(s.Split('/')[0], out temp) && s.IndexOfAny(new char[] { ' ', ',', '"' }) == -1)
                        list.Add(s);
                }
                servers[item.Key] = list;
            }

            // the EU list has some middle east ips in it, remove them
            if (servers.ContainsKey("OW2-EU") && servers.ContainsKey("OW2-MiddleEast"))
                servers["OW2-EU"].RemoveAll(x => servers["OW2-MiddleEast"].Contains(x));

            foreach (string key in servers.Keys)
            {
                CheckBox c = new CheckBox();
                c.Appearance = Appearance.Button;
                c.FlatStyle = FlatStyle.Flat;
                c.FlatAppearance.BorderSize = 0;
                c.FlatAppearance.CheckedBackColor = red;
                c.BackColor = card;
                c.TextAlign = ContentAlignment.MiddleCenter;
                c.Size = new Size(153, 70);
                c.Margin = new Padding(4);
                c.Tag = key;
                c.Text = key.Replace("OW2-", "");
                c.Checked = Netsh("show rule name=\"OWSB " + key + "\"") == 0;
                boxes.Add(c);
                panel.Controls.Add(c);
            }
            status.Text = offline
                ? T("Offline: using saved list from ", "بدون نت: قائمة محفوظة بتاريخ ") + File.GetLastWriteTime(cache).ToShortDateString()
                : T("Ready. Close the game before applying.", "جاهز. قفل اللعبة قبل التطبيق.");
        }
        catch (Exception ex)
        {
            status.Text = "Couldn't load the server list. Check your internet.";
            MessageBox.Show(ex.Message);
        }
    }

    int Netsh(string args)
    {
        var info = new ProcessStartInfo("netsh", "advfirewall firewall " + args);
        info.UseShellExecute = false;
        info.CreateNoWindow = true;
        info.RedirectStandardOutput = true;
        Process p = Process.Start(info);
        p.StandardOutput.ReadToEnd();
        p.WaitForExit();
        return p.ExitCode;
    }

    void RemoveAll()
    {
        foreach (string key in servers.Keys)
            Netsh("delete rule name=\"OWSB " + key + "\"");
    }

    void ApplyClick(object sender, EventArgs e)
    {
        if (boxes.Count == 0) return;
        int count = boxes.FindAll(b => b.Checked).Count;
        if (count == boxes.Count)
        {
            MessageBox.Show("You can't block everything, leave at least one server.");
            return;
        }
        if (count > 0 && !IsGame(gamePath))
        {
            var dialog = new OpenFileDialog();
            dialog.Title = "Select Overwatch.exe";
            dialog.Filter = "Overwatch.exe|Overwatch.exe";
            if (dialog.ShowDialog() != DialogResult.OK) return;
            if (!IsGame(dialog.FileName))
            {
                MessageBox.Show(T("Please select Overwatch.exe", "اختر ملف Overwatch.exe"));
                return;
            }
            gamePath = dialog.FileName;
            SaveSettings();
        }

        RemoveAll();
        foreach (CheckBox c in boxes)
        {
            if (!c.Checked) continue;
            string key = (string)c.Tag;
            int result = Netsh("add rule name=\"OWSB " + key + "\" dir=out action=block program=\"" + gamePath +
                "\" protocol=UDP remoteport=6250,12000-64000 remoteip=" + string.Join(",", servers[key].ToArray()));
            if (result != 0)
            {
                status.Text = "Something went wrong with " + c.Text;
                return;
            }
        }
        status.Text = "Done! Blocked " + count + " regions. Restart the game.";
    }

    bool IsGame(string path)
    {
        return File.Exists(path) && Path.GetFileName(path).Equals("Overwatch.exe", StringComparison.OrdinalIgnoreCase);
    }

    void SaveClick(object sender, EventArgs e)
    {
        if (boxes.Count == 0) return;
        preset = string.Join(",", boxes.FindAll(b => b.Checked).ConvertAll(b => (string)b.Tag).ToArray());
        SaveSettings();
        status.Text = T("Preset saved", "انحفظ اختيارك");
    }

    void LoadClick(object sender, EventArgs e)
    {
        if (preset == "")
        {
            status.Text = T("No saved preset", "ما فيه اختيار محفوظ");
            return;
        }
        var saved = new List<string>(preset.Split(','));
        foreach (CheckBox c in boxes) c.Checked = saved.Contains((string)c.Tag);
        status.Text = T("Loaded. Now press Apply.", "تم، الحين اضغط تطبيق.");
    }

    void MeClick(object sender, EventArgs e)
    {
        foreach (CheckBox c in boxes)
            c.Checked = (string)c.Tag == "OW2-MiddleEast";
        ApplyClick(sender, e);
    }

    void UnblockClick(object sender, EventArgs e)
    {
        RemoveAll();
        foreach (CheckBox c in boxes) c.Checked = false;
        status.Text = "Everything is unblocked.";
    }
}
