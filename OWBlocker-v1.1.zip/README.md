# OW Server Blocker

Pick which Overwatch server regions to block. Uses Windows Firewall rules for Overwatch.exe only.
برنامج يخليك تبلك مناطق سيرفرات أوفر واتش.

## Features
- Block any region, or Middle East in one click
- Panic key `Ctrl+Alt+U` to unblock all (app must be open)
- Optional: block only while the app is open
- Save / load your preset
- Arabic and English
- Offline copy of the last server list
- Estimated ping per region
- Minimizes to the tray
- Update notification (set `repo` and `version` in Program.cs)

## Build
Run `build.bat`, then run `OWBlocker.exe` as admin.

## Warnings
- Use at your own risk. Being matched to a blocked server may stop you joining and give a leaver penalty.
- Party members may pull you to a server you blocked.
- If the app is killed or crashes, blocks stay. Open it and press Unblock all.
- Not affiliated with Blizzard.

## Credits
Server list: https://github.com/Qiiks/ow2-server-list (based on foryVERX/Overwatch-Server-Selector)
